# -*- coding: utf-8 -*-
import base64
import io
import logging
import re

from odoo import api, fields, models, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

try:
    import pdfplumber
except ImportError:
    pdfplumber = None

try:
    import pytesseract
    from PIL import Image
except ImportError:
    pytesseract = None
    Image = None


def _clean(text):
    """Colapsa espacios/saltos de línea múltiples para facilitar las regex."""
    if not text:
        return ''
    return re.sub(r'[ \t]+', ' ', text)


def _digits_only(text):
    return re.sub(r'\D', '', text or '')


def _search(pattern, text, group=1, flags=re.IGNORECASE):
    m = re.search(pattern, text, flags)
    if not m:
        return ''
    try:
        return (m.group(group) or '').strip(' \n\t.:|_-')
    except IndexError:
        return ''


class RutImportWizard(models.TransientModel):
    _name = 'rut.import.wizard'
    _description = 'Asistente de importación de contacto desde RUT (PDF DIAN)'

    state = fields.Selection(
        [('draft', 'Cargar PDF'),
         ('preview', 'Revisar datos'),
         ('done', 'Contacto creado')],
        default='draft', string='Estado')

    pdf_file = fields.Binary(string='Archivo RUT (PDF)', attachment=False)
    pdf_filename = fields.Char(string='Nombre del archivo')

    # --- Campos extraídos / editables antes de crear el contacto ---
    company_type = fields.Selection(
        [('company', 'Empresa (persona jurídica)'),
         ('person', 'Persona natural')],
        default='company', string='Tipo de contribuyente')

    name = fields.Char(string='Razón social / Nombre completo')
    trade_name = fields.Char(string='Nombre comercial')
    vat_number = fields.Char(string='NIT (sin DV)')
    vat_dv = fields.Char(string='Dígito de verificación (DV)')

    street = fields.Char(string='Dirección')
    city = fields.Char(string='Ciudad/Municipio')
    state_id = fields.Many2one('res.country.state', string='Departamento')
    country_id = fields.Many2one('res.country', string='País')

    email = fields.Char(string='Correo electrónico')
    phone = fields.Char(string='Teléfono 1')
    mobile = fields.Char(string='Teléfono 2 / Móvil')

    legal_rep_name = fields.Char(string='Representante legal')
    legal_rep_doc_type = fields.Char(string='Tipo doc. representante')
    legal_rep_vat = fields.Char(string='Identificación del representante legal')
    create_legal_rep_contact = fields.Boolean(
        string='Crear representante legal como contacto hijo', default=True)

    # --- Casilla 53: Responsabilidades, calidades y atributos (DIAN) ---
    responsibilities_text = fields.Text(
        string='Responsabilidades RUT (casilla 53)', readonly=True)
    l10n_co_iva_responsible = fields.Boolean(
        string='Responsable de IVA (código 48)')
    l10n_co_inc_responsible = fields.Boolean(
        string='Responsable de Impuesto Nacional al Consumo (código 33)')
    l10n_co_available = fields.Boolean(
        string='Localización colombiana disponible', compute='_compute_l10n_co_available')

    existing_partner_id = fields.Many2one(
        'res.partner', string='Actualizar contacto existente',
        help='Déjelo vacío para crear un contacto nuevo.')

    raw_text = fields.Text(string='Texto reconocido (OCR)', readonly=True)
    partner_id = fields.Many2one('res.partner', string='Contacto creado', readonly=True)

    @api.depends_context('uid')
    def _compute_l10n_co_available(self):
        pfields = self.env['res.partner']._fields
        available = 'l10n_latam_identification_type_id' in pfields
        for rec in self:
            rec.l10n_co_available = available

    # ------------------------------------------------------------------
    # Extracción OCR
    # ------------------------------------------------------------------
    def _check_dependencies(self):
        missing = []
        if pdfplumber is None:
            missing.append('pdfplumber')
        if pytesseract is None or Image is None:
            missing.append('pytesseract / Pillow')
        if missing:
            raise UserError(_(
                "Faltan librerías Python en el servidor para leer el PDF: %s.\n"
                "Instálelas con:\n"
                "  pip install pdfplumber pytesseract Pillow\n"
                "Y asegúrese de tener instalado el binario 'tesseract-ocr' "
                "(con el paquete de idioma español 'tesseract-ocr-spa')."
            ) % ', '.join(missing))

    def _ocr_page(self, page):
        """Renderiza una página de pdfplumber a imagen y le aplica OCR."""
        img = page.to_image(resolution=300).original
        try:
            return pytesseract.image_to_string(img, lang='spa+eng')
        except Exception:
            # El paquete de idioma español puede no estar instalado.
            _logger.warning(
                "No se pudo usar el idioma 'spa' en Tesseract, "
                "reintentando en inglés únicamente.")
            return pytesseract.image_to_string(img, lang='eng')

    def action_extract(self):
        self.ensure_one()
        self._check_dependencies()
        if not self.pdf_file:
            raise UserError(_("Debe adjuntar el PDF del RUT antes de continuar."))

        pdf_bytes = base64.b64decode(self.pdf_file)
        try:
            with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
                texts = []
                # Hoja 1: identificación / ubicación / clasificación.
                if len(pdf.pages) >= 1:
                    texts.append(_clean(self._ocr_page(pdf.pages[0])))
                # Hoja 3 (índice 2): representación legal, si existe.
                if len(pdf.pages) >= 3:
                    texts.append(_clean(self._ocr_page(pdf.pages[2])))
        except Exception as exc:
            raise UserError(_(
                "No fue posible procesar el PDF: %s") % exc)

        page1 = texts[0] if texts else ''
        page3 = texts[1] if len(texts) > 1 else ''
        full_text = '\n'.join(texts)

        values = self._parse_rut_text(page1, page3)
        values['raw_text'] = full_text
        values['state'] = 'preview'
        self.write(values)

        return self._reopen_view()

    # ------------------------------------------------------------------
    # Parsing / mapeo de campos
    # ------------------------------------------------------------------
    def _parse_rut_text(self, page1, page3):
        values = {}

        # --- Tipo de contribuyente (24) ---
        tipo = _search(r'Tipo de contribuyente[^\n]*\n\s*([^\n]{3,40})', page1)
        if tipo:
            values['company_type'] = 'person' if 'natural' in tipo.lower() else 'company'

        # --- NIT y DV (5-6) ---
        # El texto que sigue a "(NIT)" es ruidoso y varía según la
        # pasada de OCR (a veces "Dirección" sale bien, otras mal), así
        # que en vez de adivinar la palabra siguiente para cortar el
        # bloque, se ancla SOLO en "(NIT)" (muy estable, va entre
        # paréntesis) y se toma una ventana fija de caracteres después.
        # Dentro de esa ventana: la racha de dígitos más larga es casi
        # siempre el NIT real (9-10 dígitos); los números sueltos de
        # las etiquetas ("6", "12", "14") son mucho más cortos y quedan
        # descartados. El DV se busca como dígito aislado DESPUÉS del
        # NIT (nunca antes), para no confundirlo con esos números de
        # etiqueta que aparecen primero en el texto.
        nit_anchor = re.search(r'\(NIT\)', page1, re.IGNORECASE)
        if nit_anchor:
            window = page1[nit_anchor.end():nit_anchor.end() + 150]
            digit_runs = list(re.finditer(r'\d(?:[ .|_-]?\d){6,14}', window))
            if digit_runs:
                best_run = max(
                    digit_runs, key=lambda m: len(_digits_only(m.group(0))))
                nit_digits = _digits_only(best_run.group(0))
                # El NIT colombiano tiene máximo 10 dígitos (sin DV).
                values['vat_number'] = nit_digits[:10]
                tail = window[best_run.end():best_run.end() + 15]
                dv_match = re.search(r'(?<!\d)(\d)(?!\d)', tail)
                if dv_match:
                    values['vat_dv'] = dv_match.group(1)

        # --- Razón social (35) o nombres (33-34) para persona natural ---
        razon_social = _search(r'Raz[oó]n social[^\n]*\n\s*([^\n]{3,120})', page1)
        if razon_social:
            values['name'] = razon_social.title() if razon_social.isupper() else razon_social

        # --- Nombre comercial (36) ---
        nombre_comercial = _search(r'Nombre comercial[^\n]*\n\s*([^\n]{3,120})', page1)
        if nombre_comercial:
            values['trade_name'] = nombre_comercial

        # --- País / Departamento / Ciudad (38-40) ---
        # Estas tres casillas se imprimen en UNA sola línea de etiquetas
        # ("38. País 39. Departamento 40. Ciudad/Municipio") y sus valores
        # en la línea siguiente, también juntos en un solo renglón
        # ("COLOMBIA 1 6 9 | Antioquia 0 5 | Medellín 00 1"). Un patrón
        # que solo busca "una palabra seguida de un dígito" siempre
        # encuentra primero el país, así que en vez de eso se extraen
        # los TRES tokens de esa línea de valores, en orden.
        country = False
        try:
            ubicacion = _search(
                r'38\.\s*Pa[ií]s.*?40\.\s*Ciudad[^\n]*\n([^\n]+)',
                page1, flags=re.IGNORECASE | re.DOTALL)
            tokens = re.findall(
                r'([A-Za-zÁÉÍÓÚÑáéíóúñ]{3,25})\s*\d', ubicacion) if ubicacion else []
            pais = tokens[0] if len(tokens) > 0 else ''
            depto = tokens[1] if len(tokens) > 1 else ''
            ciudad = tokens[2] if len(tokens) > 2 else ''

            if pais:
                country = self.env['res.country'].search(
                    [('name', '=ilike', pais.strip())], limit=1)
            if not country:
                # El RUT es un formulario colombiano: Colombia por defecto.
                country = self.env['res.country'].search(
                    [('code', '=', 'CO')], limit=1)
            if country:
                values['country_id'] = country.id

            if depto and country:
                state = self.env['res.country.state'].search(
                    [('country_id', '=', country.id),
                     ('name', 'ilike', depto.strip())], limit=1)
                if state:
                    values['state_id'] = state.id

            if ciudad:
                values['city'] = ciudad.strip().title()
        except Exception:
            _logger.warning(
                "No se pudo extraer país/departamento/ciudad del RUT",
                exc_info=True)

        # --- Dirección principal (41) ---
        try:
            direccion = _search(
                r'Direcci[oó]n principal[^\n]*\n\s*([^\n]{4,100})', page1)
            if direccion:
                values['street'] = direccion.strip()
        except Exception:
            _logger.warning("No se pudo extraer la dirección del RUT", exc_info=True)

        # --- Correo electrónico (42) ---
        try:
            correo = _search(
                r'([\w.\-]+)\s*@\s*([\w\-]+(?:\s*\.\s*[\w\-]+)+)', page1, group=0)
            if correo:
                values['email'] = re.sub(r'\s+', '', correo).lower()
        except Exception:
            _logger.warning("No se pudo extraer el correo del RUT", exc_info=True)

        # --- Teléfono 1 y 2 (44-45) ---
        # Se ancla en el número de casilla ("44.", "45."), que el OCR lee
        # de forma muy estable, y no en la palabra "Teléfono" (que puede
        # salir como "Teléfong", "Telefonq", etc.). Todo lo que no sea
        # dígito dentro del tramo capturado se descarta.
        try:
            tel1_m = re.search(
                r'44\.[^\n]{0,20}?(.*?)45\.', page1, re.IGNORECASE | re.DOTALL)
            if tel1_m:
                digits = _digits_only(tel1_m.group(1))
                if len(digits) >= 7:
                    values['phone'] = digits[-10:]

            tel2_m = re.search(r'45\.[^\n]{0,20}?([^\n]*)', page1, re.IGNORECASE)
            if tel2_m:
                digits = _digits_only(tel2_m.group(1))
                if len(digits) >= 7:
                    values['mobile'] = digits[-10:]
        except Exception:
            _logger.warning("No se pudo extraer los teléfonos del RUT", exc_info=True)



        # --- Responsabilidades, calidades y atributos (casilla 53) ---
        # El OCR de la cuadrícula de códigos (fila de casillas 1-26) es muy
        # poco confiable; en cambio, la DIAN imprime debajo una lista de
        # textos "CODIGO- Descripción" solo para las responsabilidades que
        # aplican al contribuyente, y esa lista es mucho más legible.
        resp_block = _search(
            r'Responsabilidades,?\s*Calidades\s*y\s*Atributos(.*?)Usuarios aduaneros',
            page1, flags=re.IGNORECASE | re.DOTALL)
        codes_found = []
        if resp_block:
            resp_lines = re.findall(
                r'(\d{2})\s*[-–]\s*([^\n]{3,90})', resp_block)
            if resp_lines:
                values['responsibilities_text'] = '\n'.join(
                    '%s - %s' % (code, desc.strip())
                    for code, desc in resp_lines)
                codes_found = [code for code, _desc in resp_lines]
        values['l10n_co_iva_responsible'] = '48' in codes_found
        values['l10n_co_inc_responsible'] = '33' in codes_found

        # --- Representante legal (hoja 3) ---
        if page3:
            apellido1 = _search(r'104\.\s*Primer apellido[^\n]*\n\s*([^\n]{2,40})', page3)
            apellido2 = _search(r'105\.\s*Segundo apellido[^\n]*\n\s*([^\n]{0,40})', page3)
            nombre1 = _search(r'106\.\s*Primer nombre[^\n]*\n\s*([^\n]{2,40})', page3)
            otros_nombres = _search(r'107\.\s*Otros nombres[^\n]*\n\s*([^\n]{0,40})', page3)
            nombre_completo = ' '.join(
                p.strip() for p in
                [nombre1, otros_nombres, apellido1, apellido2] if p and p.strip())
            if nombre_completo:
                values['legal_rep_name'] = nombre_completo.title()

            tipo_doc = _search(r'100\.\s*Tipo de documento[^\n]*\n\s*([^\n]{3,40})', page3)
            if tipo_doc:
                values['legal_rep_doc_type'] = tipo_doc.strip()

            doc_num = _search(
                r'101\.\s*N[uú]mero de identificaci[oó]n(.*?)(?:102\.|103\.)',
                page3, flags=re.IGNORECASE | re.DOTALL)
            if doc_num:
                digits = _digits_only(doc_num)
                if digits:
                    values['legal_rep_vat'] = digits

        return values

    # ------------------------------------------------------------------
    # Integración opcional con l10n_co / l10n_latam_base
    # ------------------------------------------------------------------
    def _get_l10n_co_extra_vals(self):
        """Devuelve valores adicionales sólo para los campos que
        efectivamente existan en res.partner (según los módulos de
        localización colombiana instalados). Nunca falla si el campo o
        el modelo no existen: en ese caso simplemente no se completa.
        """
        vals = {}
        Partner = self.env['res.partner']
        pfields = Partner._fields

        # Tipo de identificación (NIT) vía l10n_latam_base.
        if 'l10n_latam_identification_type_id' in pfields:
            try:
                domain = [('country_id.code', '=', 'CO')] if \
                    'country_id' in self.env['l10n_latam.identification.type']._fields else []
                id_type = self.env['l10n_latam.identification.type'].search(
                    domain + [('name', '=ilike', 'NIT')], limit=1)
                if not id_type:
                    id_type = self.env['l10n_latam.identification.type'].search(
                        [('name', 'ilike', 'NIT')], limit=1)
                if id_type:
                    vals['l10n_latam_identification_type_id'] = id_type.id
            except Exception:
                _logger.info(
                    "No se pudo determinar l10n_latam_identification_type_id",
                    exc_info=True)

        # Régimen fiscal DIAN (IVA / INC / IVA e INC / No aplica).
        if 'l10n_co_edi_fiscal_regimen' in pfields:
            try:
                sel = pfields['l10n_co_edi_fiscal_regimen'].selection
                options = dict(sel(Partner) if callable(sel) else sel or [])
                target = self._pick_fiscal_regimen_key(options)
                if target:
                    vals['l10n_co_edi_fiscal_regimen'] = target
            except Exception:
                _logger.info(
                    "No se pudo determinar l10n_co_edi_fiscal_regimen",
                    exc_info=True)

        return vals

    def _pick_fiscal_regimen_key(self, options):
        """options: dict {clave: etiqueta} del campo selection de régimen
        fiscal. Busca la clave cuya etiqueta calce mejor con lo detectado
        en la casilla 53 del RUT (códigos 48=IVA y 33=INC)."""
        def has(label, *words):
            low = label.lower()
            return all(w in low for w in words)

        if self.l10n_co_iva_responsible and self.l10n_co_inc_responsible:
            for key, label in options.items():
                if has(label, 'iva') and has(label, 'inc'):
                    return key
        elif self.l10n_co_iva_responsible:
            for key, label in options.items():
                if has(label, 'iva') and 'inc' not in label.lower():
                    return key
        elif self.l10n_co_inc_responsible:
            for key, label in options.items():
                if has(label, 'inc') and 'iva' not in label.lower():
                    return key
        else:
            for key, label in options.items():
                low = label.lower()
                if 'no aplica' in low or 'no responsable' in low:
                    return key
        return False

    # ------------------------------------------------------------------
    # Creación del contacto
    # ------------------------------------------------------------------
    def action_create_partner(self):
        self.ensure_one()
        if not self.name:
            raise UserError(_(
                "El campo 'Razón social / Nombre completo' es obligatorio "
                "para crear el contacto."))

        extra_vals = self._get_l10n_co_extra_vals()

        # Si la localización LATAM está activa, el NIT se guarda sin el
        # guion del DV (convención de l10n_co); si no, se usa "NIT-DV".
        if extra_vals.get('l10n_latam_identification_type_id'):
            vat = self.vat_number or ''
        else:
            vat = self.vat_number or ''
            if vat and self.vat_dv:
                vat = '%s-%s' % (self.vat_number, self.vat_dv)

        partner_vals = {
            'name': self.name,
            'is_company': self.company_type == 'company',
            'company_type': self.company_type,
            'vat': vat or False,
            'street': self.street or False,
            'city': self.city or False,
            'state_id': self.state_id.id or False,
            'country_id': self.country_id.id or False,
            'email': self.email or False,
            'phone': self.phone or False,
            'mobile': self.mobile or False,
        }
        partner_vals.update(extra_vals)
        if self.trade_name:
            partner_vals['comment'] = _('Nombre comercial: %s') % self.trade_name
        if self.responsibilities_text:
            note = _('Responsabilidades RUT (casilla 53):\n%s') % self.responsibilities_text
            partner_vals['comment'] = (
                '%s\n\n%s' % (partner_vals['comment'], note)
                if partner_vals.get('comment') else note)

        if self.existing_partner_id:
            self.existing_partner_id.write(partner_vals)
            partner = self.existing_partner_id
        else:
            partner = self.env['res.partner'].create(partner_vals)

        if self.create_legal_rep_contact and self.legal_rep_name:
            existing_rep = self.env['res.partner'].search([
                ('parent_id', '=', partner.id),
                ('name', '=', self.legal_rep_name),
            ], limit=1)
            if not existing_rep:
                self.env['res.partner'].create({
                    'name': self.legal_rep_name,
                    'parent_id': partner.id,
                    'function': _('Representante legal'),
                    'type': 'contact',
                    'company_type': 'person',
                    'vat': self.legal_rep_vat or False,
                })

        self.write({'partner_id': partner.id, 'state': 'done'})

        return {
            'type': 'ir.actions.act_window',
            'res_model': 'res.partner',
            'res_id': partner.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def action_back_to_draft(self):
        self.ensure_one()
        self.write({'state': 'draft'})
        return self._reopen_view()

    def _reopen_view(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'rut.import.wizard',
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }
