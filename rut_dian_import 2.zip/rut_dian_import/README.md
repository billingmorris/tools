# Importar Contacto desde RUT (PDF DIAN) — Odoo 16 Community

Módulo que agrega un asistente en **Contactos → Configuración → Importar
desde RUT (PDF)** para crear (o actualizar) un contacto a partir del PDF
del RUT expedido por la DIAN.

## ¿Por qué OCR?

El PDF del RUT que genera la DIAN **no tiene capa de texto**: cada hoja es
en realidad una imagen (se comprobó con el archivo de ejemplo
`RUT_PROVEO_NET_S_A_S_.pdf`: 0 caracteres de texto, 1 imagen por página).
Por eso el módulo usa `pdfplumber` para rasterizar cada página y
`pytesseract` (Tesseract OCR) para reconocer el texto, en lugar de leer
texto embebido.

**El OCR nunca es 100% exacto sobre un formulario escaneado.** Por eso el
asistente tiene una pantalla intermedia de **revisión/edición** de los
datos antes de crear el contacto: nunca crea el contacto "a ciegas".

## Instalación

1. Copie la carpeta `rut_dian_import` a su carpeta de addons de Odoo 16.
2. Instale las dependencias Python en el entorno del servidor Odoo:

   ```bash
   pip install pdfplumber pytesseract Pillow
   ```

3. Instale Tesseract OCR y el paquete de idioma español (Debian/Ubuntu):

   ```bash
   apt-get install tesseract-ocr tesseract-ocr-spa poppler-utils
   ```

4. Actualice la lista de aplicaciones e instale el módulo
   **"Importar Contacto desde RUT (PDF DIAN)"** desde Odoo.

## Uso

1. Vaya a **Contactos → Configuración → Importar desde RUT (PDF)**.
2. Adjunte el PDF del RUT.
3. Pulse **"Extraer datos del PDF"**.
4. Revise/corrija los campos (NIT, razón social, dirección, ciudad,
   departamento, teléfonos, correo, representante legal, etc.).
5. Pulse **"Crear contacto"**.

## Mapeo de campos (formulario RUT → `res.partner`)

| Casilla RUT                              | Campo en Odoo (`res.partner`)      |
|-------------------------------------------|-------------------------------------|
| 24. Tipo de contribuyente                 | `company_type` / `is_company`       |
| 5-6. NIT y DV                             | `vat` (formato `NIT-DV`)            |
| 35. Razón social (o 33-34 nombres)        | `name`                              |
| 36. Nombre comercial                      | `comment` (referencia)              |
| 38. País                                  | `country_id`                        |
| 39. Departamento                          | `state_id`                          |
| 40. Ciudad/Municipio                      | `city`                              |
| 41. Dirección principal                   | `street`                            |
| 42. Correo electrónico                    | `email`                             |
| 44. Teléfono 1                            | `phone`                             |
| 45. Teléfono 2                            | `mobile`                            |
| Hoja 3 — Representación (nombre + doc.)   | Contacto hijo (`type=contact`, `function="Representante legal"`) |

## Integración opcional con `l10n_co` / `l10n_latam_base`

Si la base de datos tiene instalada la localización colombiana, el
asistente detecta automáticamente (vía `_fields`) qué campos existen en
`res.partner` y completa, **solo si existen**, sin fallar si no:

* `l10n_latam_identification_type_id` → se busca el tipo "NIT".
* `vat` → si hay identificación LATAM, se guarda el NIT **sin** el DV
  (convención de `l10n_co`); si no, se guarda como `NIT-DV`.
* `l10n_co_edi_fiscal_regimen` → se infiere a partir de los códigos de la
  casilla 53 del RUT: código **48** = responsable de IVA, código **33**
  = responsable de Impuesto Nacional al Consumo (INC). El asistente
  busca en las opciones del propio campo (`selection`) la que mejor
  coincide ("IVA", "INC", "IVA e INC", "No aplica"), por lo que funciona
  aunque los valores exactos cambien entre versiones del módulo.

Estos dos checkboxes (`l10n_co_iva_responsible` / `l10n_co_inc_responsible`)
son editables en la pantalla de revisión, por si el OCR no detecta bien
la lista de responsabilidades.

**Importante:** los nombres técnicos exactos de los campos de
`l10n_co_edi` pueden variar según la versión/mantenedor del módulo
(OCA, Jorels, Carvajal, etc.). Si en su instalación el campo se llama
distinto, ajuste la constante en
`_get_l10n_co_extra_vals()` (`wizard/rut_import_wizard.py`) — el resto
del wizard sigue funcionando igual aunque ese campo no exista, ya que
la detección es defensiva (`try/except` + verificación de `_fields`).

Los "Obligaciones y Responsabilidades" tipo `O-13/O-15/O-23/O-47` que
usa el módulo de facturación electrónica **no** se completan
automáticamente, porque no corresponden 1:1 con los códigos numéricos
de la casilla 53 del RUT: quedan listados en el campo de notas del
contacto para que los asigne manualmente en
*Contacto → Ventas y Compras → Información fiscal*.

## Notas y posibles mejoras

* La extracción de Departamento/Ciudad depende de que el nombre coincida
  (aunque sea parcialmente) con los registros de `res.country.state` /
  no existe un modelo de municipios en Odoo estándar, por lo que la
  ciudad se guarda como texto libre en `city`.
* Puede editar las expresiones regulares en
  `wizard/rut_import_wizard.py::_parse_rut_text` si la DIAN cambia el
  formato del formulario o si su copia escaneada tiene menor calidad.
